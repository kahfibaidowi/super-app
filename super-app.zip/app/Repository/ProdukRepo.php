<?php

namespace App\Repository;

use App\Models\ProdukModel;

class ProdukRepo{

    public static function gets($params)
    {
        $params['per_page']=isset($params['per_page'])?trim($params['per_page']):"";
        $params['q']=isset($params['q'])?$params['q']:"";
        $params['id_kategori']=isset($params['id_kategori'])?$params['id_kategori']:"";

        //query
        $query=ProdukModel::with("kategori:id_kategori,type,nested,nama_kategori,kode", "kategori.parent:id_kategori,nested,nama_kategori,kode");
        $query=$query->where(function($q)use($params){
            $q->where("nama_produk", "like", "%".$params['q']."%")
                ->orWhere("no_sku", "like", "%".$params['q']."%");
        });
        //--id_kategori
        if($params['id_kategori']!=""){
            $query=$query->where("id_kategori", $params['id_kategori']);
        }

        $query=$query->orderByDesc("id_produk");

        //return
        return $query->paginate($params['per_page'])->toArray();
    }

    public static function get($id)
    {
        //query
        $query=ProdukModel::with("kategori:id_kategori,type,nested,nama_kategori,kode", "kategori.parent:id_kategori,nested,nama_kategori,kode");
        $query=$query->where("id_produk", $id);

        //return
        return $query->first()->toArray();
    }
}