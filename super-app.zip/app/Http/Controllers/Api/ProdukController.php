<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use App\Models\ProdukModel;
use App\Repository\ProdukRepo;

class ProdukController extends Controller
{
    
    public function add(Request $request)
    {
        $login_data=$request['__data_user'];
        $req=$request->all();

        //ROLE AUTHENTICATION
        if(!in_array($login_data['role']['privilege'], ['admin'])){
            return response('Not Allowed.', 403);
        }

        //VALIDATION
        $validation=Validator::make($req, [
            'id_kategori'   =>"required|exists:App\Models\KategoriModel",
            'no_sku'        =>"required",
            'nama_produk'   =>"required",
            'satuan'        =>"required",
            'harga_jual'    =>"required|numeric",
            'foto_produk'   =>"present"
        ]);
        if($validation->fails()){
            return response()->json([
                'error' =>"VALIDATION_ERROR",
                'data'  =>$validation->errors()->first()
            ], 400);
        }

        //SUCCESS
        DB::transaction(function()use($req){
            ProdukModel::create([
                'id_kategori'   =>$req['id_kategori'],
                'no_sku'        =>$req['no_sku'],
                'nama_produk'   =>$req['nama_produk'],
                'satuan'        =>$req['satuan'],
                'harga_jual'    =>$req['harga_jual'],
                'foto_produk'   =>$req['foto_produk'],
                'qty_incoming'  =>0,
                'qty_outcoming' =>0,
                'qty_real'      =>0,
                'qty_gudang'    =>0
            ]);
        });

        return response()->json([
            'status'=>"ok"
        ]);
    }

    public function update(Request $request, $id)
    {
        $login_data=$request['__data_user'];
        $req=$request->all();

        //ROLE AUTHENTICATION
        if(!in_array($login_data['role']['privilege'], ['admin'])){
            return response('Not Allowed.', 403);
        }

        //VALIDATION
        $req['id_produk']=$id;
        $validation=Validator::make($req, [
            'id_produk'       =>[
                "required",
                Rule::exists("App\Models\ProdukModel")
            ],
            'id_kategori'   =>"required|exists:App\Models\KategoriModel",
            'no_sku'        =>"required",
            'nama_produk'   =>"required",
            'satuan'        =>"required",
            'harga_jual'    =>"required|numeric",
            'foto_produk'   =>"present"
        ]);
        if($validation->fails()){
            return response()->json([
                'error' =>"VALIDATION_ERROR",
                'data'  =>$validation->errors()->first()
            ], 400);
        }

        //SUCCESS
        DB::transaction(function()use($req){
            $data_update=[
                'id_kategori'   =>$req['id_kategori'],
                'no_sku'        =>$req['no_sku'],
                'nama_produk'   =>$req['nama_produk'],
                'satuan'        =>$req['satuan'],
                'harga_jual'    =>$req['harga_jual'],
                'foto_produk'   =>$req['foto_produk']
            ];

            ProdukModel::where("id_produk", $req['id_produk'])
                ->update($data_update);
        });

        return response()->json([
            'status'=>"ok"
        ]);
    }

    public function delete(Request $request, $id)
    {
        $login_data=$request['__data_user'];
        $req=$request->all();

        //ROLE AUTHENTICATION
        if(!in_array($login_data['role']['privilege'], ['admin'])){
            return response('Not Allowed.', 403);
        }

        //VALIDATION
        $req['id_produk']=$id;
        $validation=Validator::make($req, [
            'id_produk'   =>[
                "required",
                Rule::exists("App\Models\ProdukModel")
            ],
        ]);
        if($validation->fails()){
            return response()->json([
                'error' =>"VALIDATION_ERROR",
                'data'  =>$validation->errors()->first()
            ], 400);
        }

        //SUCCESS
        DB::transaction(function()use($req){
            ProdukModel::where("id_produk", $req['id_produk'])->delete();
        });

        return response()->json([
            'status'=>"ok"
        ]);
    }

    public function gets(Request $request)
    {
        $login_data=$request['__data_user'];
        $req=$request->all();

        //ROLE AUTHENTICATION
        // if(!in_array($login_data['role']['privilege], ['admin'])){
        //     return response('Not Allowed.', 403);
        // }

        //VALIDATION
        $validation=Validator::make($req, [
            'per_page'      =>"nullable|integer|min:1",
            'q'             =>"nullable",
            'id_kategori'   =>"nullable"
        ]);
        if($validation->fails()){
            return response()->json([
                'error' =>"VALIDATION_ERROR",
                'data'  =>$validation->errors()->first()
            ], 400);
        }

        //SUCCESS
        $produk=ProdukRepo::gets($req);

        return response()->json([
            'first_page'    =>1,
            'current_page'  =>$produk['current_page'],
            'last_page'     =>$produk['last_page'],
            'total'         =>$produk['total'],
            'data'          =>$produk['data']
        ]);
    }

    public function get(Request $request, $id)
    {
        $login_data=$request['__data_user'];
        $req=$request->all();

        //ROLE AUTHENTICATION
        // if(!in_array($login_data['role']['privilege], ['admin'])){
        //     return response('Not Allowed.', 403);
        // }

        //VALIDATION
        $req['id_produk']=$id;
        $validation=Validator::make($req, [
            'id_produk'   =>[
                "required",
                Rule::exists("App\Models\ProdukModel")
            ],
        ]);
        if($validation->fails()){
            return response()->json([
                'error' =>"VALIDATION_ERROR",
                'data'  =>$validation->errors()->first()
            ], 400);
        }

        //SUCCESS
        $produk=ProdukRepo::get($req['id_produk']);

        return response()->json([
            'data'          =>$produk
        ]);
    }
}
