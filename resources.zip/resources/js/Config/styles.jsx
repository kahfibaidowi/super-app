export const table_pdf={
    page: {
        flexDirection: 'row',
        backgroundColor: '#E4E4E4'
    },
        section: {
        margin: 10,
        padding: 10,
        flexGrow: 1
    }
}